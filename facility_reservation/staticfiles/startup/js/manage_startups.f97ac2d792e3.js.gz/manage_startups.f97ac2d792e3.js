   	
	jQuery(document).ready(function() {
		jQuery('#new').DataTable({
			"searching": false,
			"paging": true, 
			"info": false,         
			"lengthChange":false
		});		
	} )
	jQuery(document).ready(function() {	
		jQuery('#screening').DataTable({
			"searching": false,
			"paging": true, 
			"info": false,         
			"lengthChange":false		
		});			
	} )
	jQuery(document).ready(function() {			
		jQuery('#approved').DataTable({
			"searching": false,
			"paging": true, 
			"info": false,         
			"lengthChange":false
		});			
	} )
	jQuery(document).ready(function() {
		jQuery('#disapproved').DataTable({
			"searching": false,
			"paging": true, 
			"info": false,         
			"lengthChange":false
		});			
	} )
